# mb.imgNavigator 2.0

__An open source jQuery component to easily create a navigator tool for your extralarge images.__

![mb.imgNavigator](http://pupunzi.com/gitHub/mb.imgNavigator.jpg)


## [go to the demo](http://pupunzi.com/#mb.components/mb.imgNavigator/imgNavigator.html)
## [go to the doc](http://wiki.github.com/pupunzi/jquery.mb.imgNavigator/)
## [go to the blog](http://pupunzi.open-lab.com/mb-jquery-components/mb-imgNavigator/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web
